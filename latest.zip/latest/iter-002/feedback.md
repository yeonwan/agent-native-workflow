**Failed phase:** gate_fail

**Failed quality gates:**
- test (fail)

test (./gradlew test) FAILED:
Failed tests:
> Task :compileTestJava FAILED

BUILD FAILED in 2s