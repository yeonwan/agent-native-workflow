**Failed phase:** gate_fail

**Failed quality gates:**
- test (fail)

test (./gradlew test) FAILED:

> Task :compileJava FAILED
/Users/timkim/dev/identity-service/src/main/java/com/fispan/identity/services/authproxy/provider/WorkdayApiEmailValidator.java:23: error: reference to OAuth2UpstreamException is ambiguous
            throw new OAuth2UpstreamException("Failed to fetch Workday profile for email validation", null);
                  ^
  both constructor OAuth2UpstreamException(String,String) in OAuth2UpstreamException and constructor OAuth2UpstreamException(String,Throwable) in OAuth2UpstreamException match
/Users/timkim/dev/identity-service/src/main/java/com/fispan/identity/client/controller/ClientController.java:63: warning: [removal] createUsersAndSendInvite(String,String,List<UserCreationRequestDto>,Status) in UserService has been deprecated and marked for removal
        return userService.createUsersAndSendInvite(
                          ^
1 error
1 warning

FAILURE: Build failed with an exception.

* What went wrong:
Execution failed for task ':compileJava'.
> Compilation failed; see the compiler error output for details.

* Try:
> Run with --info option to get more log output.
> Run with --scan to get full insights.

BUILD FAILED in 1s
1 actionable task: 1 executed